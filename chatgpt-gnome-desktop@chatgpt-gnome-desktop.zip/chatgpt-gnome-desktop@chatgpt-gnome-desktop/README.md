# ChatGPT for GNOME Desktop (Modified Version)

This is a modified version of the original [ChatGPT GNOME Extension](https://github.com/HorrorPills/ChatGPT-Gnome-Desktop-Extension) by **Rafal Mioduszewski**.

## 🔧 Description

This extension provides quick access to ChatGPT from the GNOME desktop environment. It is essentially a web wrapper with streamlined integration for modern Linux distros. Improvements in this version include:

- Improved `window.json` formatting
- Extended GNOME Shell support for versions 45–48
- Visual or UX tweaks (add your changes here if relevant)

## 📦 Original Project

Original GitHub: [https://github.com/HorrorPills/ChatGPT-Gnome-Desktop-Extension](https://github.com/HorrorPills/ChatGPT-Gnome-Desktop-Extension)  
Author: Rafal Mioduszewski  
License: MIT

## 🛠️ Modifications by [Your Name or Distro Team]

These changes were made for compatibility and design enhancements on:
- **AnduinOS**
- **openSUSE Tumbleweed**
- **Ubuntu**

This modified version retains the MIT license.

## 📜 License

This project is licensed under the terms of the MIT license. See the LICENSE file for details.

## 🧪 Installation Instructions

To install this extension manually:

1. **Download the `.zip` file** from the [Releases](./-/releases) section or this repository.
2. **Extract the zip**. You should get a folder like:


3. **Move the folder to your GNOME extensions directory**:

```bash
mkdir -p ~/.local/share/gnome-shell/extensions/
mv chatgpt-gnome-desktop@chatgpt-gnome-desktop ~/.local/share/gnome-shell/extensions/

4. logout and log back in.

5. enable the extension in either Extension or the Eextension Manager app or run:  gnome-extensions enable chatgpt-gnome-desktop@chatgpt-gnome-desktop

